﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetkProject
{
    public class DbConnect
    {
       public static NetkEntities4 entObj;
    }
}
